''' Title: Python Calculator
    Author: Nitin Singamsetty
'''

import time as t

print 'PLEASE REMEMBER TO USE THIS FORMAT TO INPUT EXPONENTS IN YOUR EQUATION ---> x ** y'

while True:
    a = input('ENTER MATH EQUATION HERE ---> ')
    print 'LOADING...'
    t.sleep(1)
    print a
    b = raw_input('PRESS THE \'ENTER KEY\' TO CONTINUE OR PRESS THE \'N KEY\' TO EXIT ---> ')
    if b == 'N':
        break
    elif b == 'n':
        break